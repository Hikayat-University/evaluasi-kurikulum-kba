# Portal Evaluasi Kurikulum — Kuttab Budi Ashari

## Deploy ke Vercel (paling cepat, gratis)
1. Buka https://vercel.com → New Project
2. Pilih "Deploy without Git" / drag-drop folder ini (atau push ke GitHub repo dulu lalu import repo-nya)
3. Framework preset: **Vite** (otomatis terdeteksi)
4. Build command: `npm run build` — Output dir: `dist` (default, biarin aja)
5. Klik Deploy. Selesai dalam ~30 detik, dapet domain `nama-project.vercel.app`
6. Mau domain sendiri (mis. evaluasi.kuttabbudiashari.id)? Settings → Domains → tambahkan, lalu arahkan DNS (CNAME) ke Vercel

## Deploy ke Netlify (alternatif)
1. Buka https://app.netlify.com → Add new site → Deploy manually (drag folder) atau Import from Git
2. Build command: `npm run build` — Publish directory: `dist`
3. Deploy → dapet domain `nama-project.netlify.app`

## Lokal (opsional, buat cek dulu sebelum deploy)
```bash
npm install
npm run dev      # preview di localhost
npm run build    # hasil production ada di folder dist/
```

## Catatan
- Semua data folder/file Google Drive ada di `src/App.tsx` (array `DATA`) — edit di situ kalau ada perubahan
- `SNAPSHOT_DATE` di baris tersebut perlu diupdate manual tiap kali datanya di-refresh
- Logo sudah embed sebagai base64, jadi nggak butuh file gambar terpisah
