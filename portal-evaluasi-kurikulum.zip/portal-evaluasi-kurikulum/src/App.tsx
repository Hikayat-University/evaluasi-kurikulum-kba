import { useState, useMemo } from "react";

// ————— Identitas Kuttab Budi Ashari —————
// green  #1C4A33 — hijau logo
// gold   #C79A3B — emas logo
// mist   #FBFAF7 — latar putih hangat
// leaf   #EDF3EE — hijau sangat muda (kartu)
const C = {
  green: "#1C4A33",
  greenDeep: "#143726",
  gold: "#C79A3B",
  goldSoft: "#F3E8D2",
  mist: "#FBFAF7",
  leaf: "#EDF3EE",
  ink: "#22301F",
  muted: "#68705F",
  line: "#E2DFD5",
};

const LOGO = "data:image/webp;base64,UklGRq4kAABXRUJQVlA4IKIkAAAwnQCdASowAiMBPmEwlEekIyIhI7X56IAMCWVu4XCA+eQ7l70f+h84a0v5TyUd0fTP/G8+rx/9S/8f979r3+q9Rv3ge4B+tvSL8wH7O/uv7uv/P/ar3c/4H1B/5//qP//2GXoF+W9+9Xw0f2n/jfuL///e1/+fsAf//gQvMX9x7VP8J/bvJP8V+i/uX5Y803rLzQ/jn2h/Q/3f92/7r7m/7Hwb+WX+H6hH4//LP8x+XP5n/We/YcC+0n2L/ef4r8m/Sj/0vQX7VewB/MP6b/vON99J9gL+g/3j/l+zL/U//L/U/mT7bv0H/Lf+3/TfAb/OP7R/1fXU///uH9JIel3d3d3d3d3d3d3d3d3d3d3d3fX7u7u7u7u7u7u7u7u7u7u7uKpfXXup7w05X4AYKq9gahV4ysiIiIiIiIiIiIiIh9VMB7LN77/nDGbiMosQMMbgK9oI7MzMzMzMzMzMzMzMv9eZy9B42chx0D3Fy7u7u7u7u7u7u7u7tGe9R1dGRaQonh+dxzXN12n3LWz2bQ5RDGjYh3h9PTTWHyHJYFo1fjzVUjLGiIiIiIiIiIfPnOG1Mw6uZpmfJmPaxKL7ZqSeuJBBxKCn3ICRmRmT4s/FReRZNBAfD3CAsF1UGyeftZoMygwEmwTygVVj5ZU+ro7tM1cOp1yU3PmGAGCq6B9NWZ3/AiIfPm+NoIRp7PwB7GzZQowKon9aqHwBtXdI8RXUz5n0d2HY+iH639cJlU7/F6HzN3prZr0P4PcQU4FLsQl2p+toPXlRA7RycCe2CZmY8pIgaw2vsPahrIRbDxsEf4QiYr90W3/IPgM4/TaEBdTyVSLa0vg7rA1c0M2YqL6VOXVSMNsnkPzw6UuMFX9TOhZh81Auw3iF9/NhujU5knfbLDGlaiRPKxYnJCkYteQR+ir6i99aueomtPyM/ebz+rvCtTLdEC4vedFjlOQfKSQge8gNKqoNOIrmgonGmySWl6Fm9of8F0M4W7PE71GR8i93OEDp8mgZMGciZOoHEKgrKNJ/HZrxqDBQ84gWDSiIvAiuow1LEGjhuw69VqQc8yOuWZaNXwXY7U0QHl6kqvMyGSExA8ze+XNn3oWVNxnHS5hbCAmLWydQTIzu7soHN4pILX9Aarga5zGmMEGsum1oUbZci2TMxP+2yDRil8Xntqk/m4L9i1H8WQN7Was+/dTArAb+4aX/84oG9y/hbAzywYajo3z3TLaC6KHPw7LZ7BOCgcPFOkMuOLpao1+LNDE5GWc+rUCZ2vYRCZcSRD0xvjwUwPlkNCehb66ePUb9UJiCoNi+/nfw8lkrZ+85o/kysApNXAilJJ5mTHShcZQ0T6kwZoFFsfZNeTRAKRmEuffOt/F7IfIt3yjGZmOkeF+con51RwaijFUGQHf5qFNp2zkv1Hs1eQcLjO5Ca2SJ27Bu6CSmluGMPmns1PMyq8PMxeTRu7ux4tkGzx+9NNJCzIS2j/MyYBrW2DC8csKcF9/t964942kg1VVVVVVVVVVVVVUviqgcd/IDnS4KSc/P9bKfSiGUfb/+eZXGVF6Jobtu7u7u7u7u7u7u7u79ofBk2lwAinhMlv8JwFT3u7u7u7u7u7u7u7u7u7ui06lxVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVIIwqqpQszMzMzMzMy9/EZmZmZcAA/v9IfaKgAAAAAAAhsvflN+i//hYIFhesrRHAbHvYMGQqanzocoNriO9h1gQLGnHg9aEJgU3+5x7bzG7fjazMsWF7/J0jIc5gApNFN93x5XgARf+iFznyyYSq+mESrDsE3R1tl7NSYk+bjZ2gL66mfMym8KwhUFLD7+56nov+A00vT39al/AI3OlGlqWg4ArmhPBsARmLwU1+seYSUg89armalmPzCYzNL9KiA/miw7X6/rZAbu5boZQMrXF1ivvHG9RUHmudAk+s10AAJXTUPAFsx3wdsQsoHCput2aH9JdZFYFmKJFq9KhLY4HyAkZRdyEcTPsMO08m2Y/01NP0IzfLha9ijXM7cMk+KL9WH22a29M8zSf+CES3dbru5SOyIJuZ4IBEdGLM9y0dTO0AAe4z7hYcQiu/fmTSfLIBVKYT7bs89CaoPulKqIJm8xWl5oyFBZykUS7vA0T/vVt12mmvBjyGRj9h2QwK/CUk3ungIAfAaxGRlnDn9GCn7ubyPrP7Ei7SMZKtqfMU+j5Qez8QIqeAIJHRLW+9mhtu1Y7OyebD/gHPgoUYNbZNMBqJuZsHZWmOiAS6CjoMFYuJMnv4L4qaxBc11BhlqSb91sDJmBgIvD8R1SFbZQTCIIwlZosXv42y8nIpLqy0Kc3ks6jVqrmjSeZa4wQEIV1TmwAVfWgZoCIIPjvZPbHRJc9EUp8VRSAehbT8pQflHoIM/O/FKSZd7WaKlm3MDUiCusb7ZUrHmsaniXbqwDfib6gGOTVovCpyw+JCRrln9Linz4FHtLcce+0ft4mDKPBKftlkf8BlR15so48jfcclo0EBGcWOvM8seQjerV/nvTTMxrwi7Qn2UQBlCupLAKIoY6SgbObUzsqfO2XYGhA8AvatxLNhM/eTcjM0wvJU+DBpghX32usSqCCMFrpUID6YhuN/NLxpvD4ddYAMwH4ZDqE/9CIZGD2pVrGtVmMr0gaRkwjUJ41t9e77nSn5OzvBBHgr7bF0M/vsq/hxVZsgX+sJMEaTR2DFtJ5ekN5C9dmo9STXGxGzZ3Tw+b5j13N9Jsc267xH7Pf8ip6K0mfoc7Z0VNwHTMjF0aLEK4YbJRljdpgXpyteALncMCm0yAzojxPICSGxVGa6oII/WIh3mSM6oW3YWPP+eRzyZ6+AOV5hl5p1R0Q7aAtPPP8ty9aWNLQIJ9M/P3UXHTI+I/yQbACi5WGiRgYBJ9yHq4HWmwCe9QhqkMTxGyjN67q/6nNbExsNcbGYqG/EC3nybMVDqDd6qdt1KvHmrLtH1w8Z2/LZudyzeaYJ5UdzyhGYJEgDtkfOfiaB7Ciz5shNKqWCOdeQtemXQk7izA7hfx+yj8DKSGvLT+knz9Iyuqygz8q3L2OTXdqCKsuHt4qKXO93CpeJmNNthS7tbvXDwwu//Er3gNZbYiaa5z48ZqMWfb6twVMmHeWaRjwYn6Bv5Ty9DXr8LSVf1bFMJik3goQsamsVy/DD4nexg1oM/74F/V0hCX3iHB4KLBiJmzt5WORTBl6x8N9ebxgwa4zjW0rfQif8z+nYVRFiH8PIWdl9RrH3930xzasd1jM6eNa9PyWNf1hIiNe9ffNH5kfwbwXzsXqKrzfrgBB4tXYjN22NVLrCZhyfhxj/uOL7Els2RKosc131TaK2PSx6Ni8DoYFCyiEV1kA/kkz2/EHKPPjghnP6dAL+SZiXu6MrU1E59Soxzb5blm1GpKaxTn64GzFMIRfA76gKCBcBEVWWt8/a4FaenMhumuhL8S9VekXe2699OIHAKhdmYjfGgxI4ivbHZZo2//KbZZ+0cRf5n9fKc0U9S+k8amr8GvWHtrqWEBBWVBxUU12Rrq5KE5iGwraSbcFqAvqkJ20IA9T85vy0RfbP4fnB8tFg9kpBF/U/85N7dDKMSodXRlZZ7hL9V7UaVQp+L2SY+pF+NkyL39t/q2ZvWZ/fXbSxEpfDBU7ul1IZe283XTJEXI0XRZLAd299z/+KxySHQn2sB4yJ8v6o5G8LDbafTA7yOPK8mjv9EW2/0sLb4z4gRTJK/owAyECUoE0A7gbI5NXRXoZ/k1/OCSUlinCAYG9t1vrMOn8yEep3punfowtxmfwnITpwhiCBrEMGj7qVslmfUu0f5yccgdx0jxFJmImq3EJHLDHwenMYMdnyplQkUp36i7j+Na6cXxt4lStT0IK7VJiDaeuJP8bSFxbtUGOPbpeGHT6tGtqf7oc3M5rT94O7DLr5HF5KGWjvcRsob+RRRA27Dah4XneW18U1K8xMIsr/jmlo7wWnEvVMbUfiJWVH78DNp1iBVhnqH4R/livgpRVlzFI8VAVvoJEE++w8nCkKxD0tKTCzv2Fg+Jy6wRi6sMFmM/ACmMvNcbaP27kvThOgDy1HtUVyAlHT5nPib4ZJAvloniN2y/I4RIm3EXYD8Y1uovJxpJAKBEqKz1M6cGTiCnqnPMkOSKOCC0aT+pYpCXEvbaiaotKnkQrT+ul7tY77jYJz9yarEXMPHAOW/TXrDX6JWTlBdC4BK4+r+Flbra+7ZGda71lq50tG4Kr9wGKaopbhM2iEjGcmoeEIMpMSmY5v7sAYK/jVvkonwm5qWJRlaE9Snx4in/XLx1fsu7hwQ+Fy5euu4C6ZX0wL0wfE2RazT9QtftEPsnLSExt3aDVveIbxAhxjtXQtBZm+5DJ+c+X2rNIawQKQcN/sxwE8J4cOs+1wY0bGAClJgLhbEWUeNlHaHBGi5TrtCyq7wyCjd2laZ3VEk8/U3fmweoHyusTz068A53EoDI/MWxzxePZAFz3Dq//NX+bHQATf0FBUIcfSBF2rqEcpXPsrXFTMlAAEyBcDpk3iVKTjFA4ozYpm6nJ0iMLjD8kWJ+ds9EGAMQfQqWv+K/KtTM9PK8CFCnTjn2WbPdKDC8/ofzLn8qpvPZSKSRD7lc+1Zq3RdAIqxlKteKmuVMRrpJ76ftyunlxokoELsuAr+3KCCXOyjxoyZ4qTAK+PmocMBW5yXcnE94fu6A03B1Z13BtV5sZxL/YFcoE8yE+EFg0HmS8w08vgU8esrsdTupoIPpwJI0K87r9zWqSMm4t+YpiKBr7HYlBSFQo2Mfn8wpiuU9JCyFrMqvNKcEj6lN7E3D6JSJqGwvGci2tXrAxBMHQJVlbAV2exKPbDixDjVjkpqRiy2kDZKFXNL6IZ6KGzHFR8nj8cuWZmnTL9uDnjg7chRutf8dyZ1FPpx5/Wvmkq1P4eymWg+duPyo9nZlS3oW1QmMBpEdW4MQN6/plN0Ocby6Qybpz20hNfA+N1NKYAnmB3m1CTJk5cmPtcoJVUbEBoYVSzsnyfUSNZZ2x/hCEEh9iSi6AboWPNiiNi0mzfNjfchLWgGvcou372NihMEwKg6S8VPQCLRZ/Qurt2XfdxWsifF6+W4chza+kYC3lH2dKIiN/FRcpRK95c25WScLIMYkWjQ2Wl3kv4zbw3z6EkIF+cFwCu6jmXzn4oovtzgjSbEUVJuK+7dlTcgOEBxAaAhenIWx8W6x3eewhMTiksRzTgL48hSOkNpZ37P/iroQ818zqo5Sjf7HhwUvcGMd6+V6Rsk78vxcuRDxHfEvGtgiznnLm2OR5s1lzBxa4J8bzYGpgm2B/vNnoAuf+bCqQmEo9/xdSVtpmm1ddFoflZ5TkzKpNGIFXEtNEYQ8vLVI9TXjHrPjiDZXc79NsLtxrGmyDQgDyPIVbCGMVXv2WZusAgJ2juSpYhLXUVAEd+bRWEMYg9jBEhVArukg9L6m7ul220HGSNc94xY+BXh+8ibTrsSW0QUO6uX+2taI9itADqcKkFftmQIgDq8ca36bUOb8bQ45qYddzHGyb4OAQExtzzeF99YRUv5op0Y3xLVishRBjhdQUsH8YNLEXKYuI6ipMz4nPL2ekNKjc0P81+KKrwGBGbHM48srpWt1IjwIyqvxhgpMboogqDJvAIkwH/fVa2Xu4fIrGTUeAGiHzLt2PT7hAEGYU0DW3QBgeObOurxDOTMs/tDSczTfaV2Khvoymcxv4TaTIge6TgDlUSYTYtIXyiVwxIzhsS4ysOwXF2fAYewDMQlr0hr6Tgbf9BwD+3mQoE3r2LLsgxtrdga3DibJfBhe2v8mSoBAHVHzEMoEeIwPDFAgvB3HuD+OsMbfQ6OhTm9pbzsWoG5Q68tlZhifst/1lKHslU0vYoAQq4ISKYNmV08hgl4h3eis+P/ie8E1+or0cGduAZ9fPe1g7r7Q2NjvMTMVxNW6ZgM5dj59faXPJFeA3dWHy/IRecnZEJHz7yxQBpFI5m7m7fYwlR/d+Xox3BlQk6qSaC2g+NRpEPfvOf7aM7v5etag8cJpj8DL8LG+ENfdOvt2HNT3cB4nlnzIn6U2xZxYdqL6fi+ycoFfzNcQ1XghpHhp1TUPbvKDTUT7wZfltWsr3Ko4+iUqyNT3v3q4El6OnDc9ahp1LHQzUuWYYTyE5ngT7Sc5Y5diUSUl6UiYO7Da9K1B8ZI/fZqfB0f68bJdQO2RRxhMwKTWi/+F6RMfdg4cSikXsQanmcRiP+n4nNaKva9R6bu8GStbo5SomhKGVnmYdIDyPBsqSQX7CVGCxHrMmGyXCyZ7zDOOAebKijBDrg2l5VuQ0VAkioFJoHIryqzp116BEjLxWGda7ixuIJHKCArSf8m/5mRyg/Tb9N1tAYPFZ830EiGShU38lU1a5sWWsG+EMpf5IhMS/RckBKcStjpCSOgSwlVabgM4UiKLY7YnxyaMIEk3LOUeSPQEu2b9U4vF4TeOdV9HNZB59vSgYfnV9ul7MQSCIshs94mO96KjIXqWbio4SfsCwrbu/AitZqxxJARc9ZZUwRrlBTpdlgvdqj2xUfejHokAM1BLL3HPTJOhaSChUumoZ2KWK+ENBzQWjkvA9GAcwh25kMJTuVJeTAtYlXeM81NY59Ux/8v4LK0MGy9sv1Z8v2VJ95C4g7bX94OGltV4BTg2Ktt99QJHQB4M88J1oDoIJ+srMafbhy8RMGK+hoIJ5fGadNAjq3EUi3xpvsrNiT49o/eOsyMRZIuml16w6p00F7O6+ErLDRr3tjsGsv97PzWbMyL7/JI250dwwz4fd8ZfQz0FDcdgYTQYCM8FNZYWujxYO8IQbeNwBwAy+/NKbR8JVTjhAU4ncqFja1sRepMrzJfvrUwb2PVb4rBTeCVBmYgn0uQ/pN6zq/CSDGSALMvR/feidiYZ4dXcChwq0zlUTt/vJStgC6xVWDrepuJ4ly14Sj93au4RtlHltiTaGTGtJcaq1HV3zWLaRvATA7sZLeoQ4wNY0RfOhTlPmqA6lOP14aEP+LlHCBQeEYt/LEEEovCns80M3U4MahEXI06NLpQAjvsGFvYDpA8ZLxf13mcXvl8FJW/qTDN1n9o2vv+P6F3qpgFsELiK4lklkY2AOTpls+4tb6tAVhZEQCFFORwwaX74G6ImPX/LjNTKbaONYZIMMSrIe8mn40S7Cp0I0GQ4fC0/Uk4d+mIka6p61D1Yvu2JmL5vSns5FQ+unlMdN24tSgGDUpsHNaTlmCQ8banLV2L82pAlk399MW9aQGYbPa+CzmPEGPdC/GOfbsJAWoufpfnDt85bkCTfL/vPZes+04I1sEqwQ/4tlpuylBNJLe+n/h7IkfsvzeAS881QXGn9PBRnnS6WoDuqYl8J0MsdxsyRx7tqmvNcykkgbY4kq23poS+mzXsd2kajfYe762kSko7IapYxoegFOa88hHrrKyIhOzho6Z4agHLfdK2X1FIKJC7/AuWCrnCNQXJ6eDIJI0gcxaCkifpgmtS/eGAxsrK4MKgaRyAVIsJ9/SCplQi13GLnxOAT2NwqHY+vttkc6in6dEjRSC1aRptj4bDEYhc2A0u0sBeyBa4wTa9EiJ31dVlEUE69OyYUzaQd+u4DjywJJHkvfnOx5x2cG/+tiwha4yoxPXQe2byHuTirT+E3HBCP0qLlNnwVgb+OP1gKLogetv9BekEUIHd8ErUnh57N7NGyeNp85jYr97EIpcEqFvgxMI9SjK+ZD5UTM8zmnOXJaL+SJ+Enc0s9pRP2Fv2/d/UABp51CuFSUuUm0bGTs5lL0JL3MRMKopZ87/tuiN7iOu7tvPg8Y7K6AcvzARs2JT8dHEp2FDVLN0PWffEimPwsq00DHusVORC3Mw8/+z6b/UoCvDk1tgRb8O4D9zJVXMG5ES41VnpIGODlyIC4GjoP0BMh1xYCe9/zaoNFu1J9PKyE2VbeQPSHq6XwziCEzY1CDv1Q3w4nCzxjTubDBipZIU4gIrUqTmR56XVW3TsVQPyGScuMvfEamNp/dleER8rUIL3syHJQt6oIV+w8pOTEy4Xh770fKcqIxOyfMrv/xEb7bUQymbbiBJSBBXF8mFlX77yZLDNrTpbWNbHvKaoi09Ztk9RJTaB5W3thYmRBTn3sXKqvythVPSxNubqypdYPEdQov7pRiHpEay59B4Gj4gb5CCh6rlc7WjZmmdViuhjTeArSINV7N4vxEBHb/Lg4vdl+A6cso0Q8Al38/J3kRQVj8afMXDw0s3b/f5Zx4liNnUmJJy/wj2sHVlBf4VQSiyxNbOAw7Tx1CyOoVIdqRmnZB8/nsbrSouM+wNCC62cZsVFP5oJtddfDn2k6b5wEvLMHEC5KKViS3SBf66IHHQEyrNO8I1jO5CKHSXxkpOyPMerQaMqPm8ECyHTVQiSH74g+HOyW+6bojZRbIlGegbL6qtIu+vm3I3zQGacr/wwJWqjTnEnt0RgVtPuapqT1md5ne91/8SlwSMda9zrAL/VZvK/L/hL/1wwywZs1dclbNNVTFh1li/I7ot/3XlZE8/vVElRMxRF0FlCMvc59ijHtFJX+/L/5xc9xrvKU9J8jAO6w67khGBDyfV9mlCq4hbRspfC8mU4ZPN3F53sWVQYqJbLxBhHBwgCLbXY2Mc0Q0Rj0A33VVX2l3Yo7iQnjcZT69ue8lq9horE0/vbBYWPVUZcrqiEpJTtyFc0I7Cquio+tA5P1xXgDxnm7O5+CFay+MAHCbqFVAWbYSYsuT1M2z5oSWkvgx64zlti3HqfBYFRD6dtj5HQ5JpioWXamz5WFGukbAK2lRLIhJcnLldJIpWYYF93WRuAD1ht0f5ieY5Q4LVMAdRSki2G6slyxLTIBpF3qpyzDplMgnq+/A+cX31zTPsydm+m/qM9aRteOuZXep6NSHztFC2odOQKugB3rU0OD+D3i8dRAUkvHUZBwsvLvBo1SLa2v8PQjoPkZHPzsz+KVQP8Oi5RGUOdDmQGr6Q4kKQIEVk+kR9FdJZYZRwt8LncuN2zSXTdwlO3A3vh08hNtqO19oFmRxZkoSA7+gFQiKgB+p56KCFvua5CqtnQP/F8CFb8wmxw81xB6kndI3lff+tHPB9FzuqN/015EXAg4k2jTlryDMcQN6gHkLyWO9rp0YKvLzG/aDX5fm/o9knWWVhyWEgk5BpnpBnALlguZJxCXaUyqL4R3vYYWhJPg2xdihoc/bGbSeTbuXuHutDn83BdFmHjJZ+HJqn3fijpDkH5HUbPONNbLF+TC8ef5GpVxdvErRpKJjfBAh/16FnljWuVLvdv6TA3cOmOCCxsbs9d3PcCEADoW8BoIyRt0Rs0Y63mAsHdR0c3Ro1EVeelvWLnLvF5f1t93W3EKN+KmtG8kOX8fKaoi0Jr1dJFB/CHgFmPDZTf6ro7pvQxxjzS7uFSTxEbV26JCFrlIKQQvlD4BurxXSapwdskZENV5bMrPsTXyjVu6mYEjYp06Btp0wu6fkji3oVschSwY/cjAMFIisH3ZYyTeNTwH/PO/n3Olgi/NEA5fSR9KQ2mnap2euvgqeR+3hDvliEA4VzmzUGE+keNNbnvgnbs9z6NNA/9tyfojnEnUAzYaOkvjc6xkOokNXVq4akDPjB7KWZZQ/TZh1FR+3IXDwBUsuG0xprUCx092oPUaPStQIxGpUKNsX81pjegFaR0Gt+c53QJ2zJCsG7XbqIY0dkMpzM09WjlEB7xsOlPpCkBbZTLWrSoo247ZHF4sKlIHCIFO2+M2X5A7dGOAKOJLYUz7YMFTFpW4zp8uHseRl3wHw6AGrvfkcgfGd3ke9Z2W97K7NDq4hwklEHcbXUiXo49azpp7l/m3uteq9r0oFqTCz4GtV/LFVdVXbn+eNZlsmEfJOJdSRvR/4Bu1arWD6UACc4p33doNJ6/z8DIC+fHwROzE2d4g+dO9cTBCnT62taIBhvEXa32WAbxffvXEkmQXGQmoBbXCBt2eWg7RScuR420LlsRGCPuxv1h0Sy2tuRaK/37sCReIC6x5q6Vyx2d8k+oi5fZa+hPu5iIpDVv8vIDg/xSquXJoES9/+a9jCG9T1R2ZCx8Sp0Ne1R3hpVh9+Z/vMfrbO4pCkG1v7njXsjJ3Wix7ypF+S0jFIyHVzIaP0TAApWrxM8Q/EdA5L2fnMoakiDsMNlhgIGBowhYT15aepGTOTAebzIQMthaFNB9ef6t43cf25JzJMbXvPvnCOKXaPS4qKHrf3VEkGs1NDMKt8Q3gB6zg4a6uTlx4EkGyMJBb87PyJs1xRQLS2Mg8C1GsMWG5F+kI+a47wND7JfmvgoDN7xTP8e+Wg2WHdkQ8CKNeSmg5YK+dxATwoLwN0orJ6aAwvMyxVHzOwOy7S8mDsF4SZWHYzEwdrxbs7ZPiNYng9MLi52GrztfRHaMCg1X0YgT157KDhcGUleIhMYIzfseAWizMHD6xZS6VzrZixuZOI3SdZOH1WPRop1Ftq40Txvp2NSkXM6XvekVr3UC14a1sdGC3LWRbmaQW8N3ZLKIbaNUyrUd5LfjylSLhCkLj9YoN13bjm7WlptzOHh5v4UDamehflIIOTuc4g/ChNyoU9BjyjIvYP0XTkRrsijW+TPrUdWiZ1HPH0wN52IoF4RD6UjVHp8LhCOLGNSXUhlzKLLKwRcd9qhPN2MGYCZef1dchb/sgiYA+T4O69+GxLXPvyOoSD9YWUpNtBj0+BUWSZYSCDHtTeh8sOHUZenun48EvODyqZMfw6+pGZel+8avMKntfHqmM0dBoAwhfrs/JgqAjum9C6SQcJj5jyzpvje9KDwiwlymr8bjevXu3vqhNUt6LICLIJiyRi9X1h7McYYmz4m6RVbHEX/q0xd+DHeRpG62i19gbQ6tsOqO5J54eV/VT1nqajEwXlx7NLB+vq8hVn2mUVCappK4dKsY4nyqp5K999I1WUeydZ2CzkCGGxhSETpFkxXNDDqBbLv0gDaaZEFz85Ny47QePFa5d/2dkPuCBc6m59cACPYRoar5lwmtuMZbqywiXk7J9cHH6cMfPhdK6cdolub0GmmsQgQEbEVhvwBdv+0Bs0VZ/cMmp2AfB3gpoof7VK2iDZJSvgSq2t7gB7P3UwxtHmM5Zux6eAVye6l3pPBZBCzc9h+V2UuSUcrvGI0O8I40DDrBSgv8gkjngEaycIjLp/6FKRzO0PeUC6Vh2/G50WGzvRHk95aFIvJ+prCwZf0drdSHSDXlPjNSUpudCtlL2hGFELG56F+9C1KiCxYkG7nVQcC0NXVpXgjRYI/HAn5qJHsrFsfwaxtuLWj0addJqqMQRejjHUaNAAAAAAAV9oMg06qx2Fq3nAZi4eJhJHJr4fWfCaBMsDe4QlsNIS3XVuOp93q9ElZ0IryhMiXxTYNXT61S2/0PqvXGweOS66equraQUNHJIe/m/p+xjfsSnR3Jm0Nw1sSRS+wMIy+UdF75YDTMivDMyd1Z6rZi+2UzW2TouVwvZL9uTDXpl9vkOCPHuCEv2anZ9zW/Jh3I06+pb6aGYRJ4mH+ugwVoHTm5GCVLKMAfv1Ku6BcfdvWbp0Dp0BGFclxXm9En9AN9Ks8IKZ0R8dHqLGyXP1e7RbxgS88jpVPDuwtupacOs7vk1EO8tO1Qo6p5U1TWsCa5C4eB5/C9bctQ0vx1AT/L4F9gPPHzk2ah+gN8wlULSV4/MDcJSaEbX7wAgvTGP5ob285mY24698xb61B4jcKmAHU7dPMJMOyT+QF9mjnWXpKamMIaptKFGALUqLYiBrL0658p/oQLHYl/ojFf69kJXWgS6DfQqNw+dXZeBvkON/P1nE838Uw2q2yezKvAAA/jvZMFnnsPFZojQHe8qlWuek15vFWd+mJxN+XRnklU/o6IRk8uSZPJpxpH4jVQaE7qRtI8Rkk7kEV5plPXKWYDoquAmCpzGDKzf5GUDeOE0ZMS/elX67aukeYrmWnA+6wx1BkINLVeKCjJGUOqGdyF6Cl4OkTUyagsJeM8YWwK/E6UcYUaGgAgylpFmg+vm2Y5Zh6XRizOhgNaMLFguEZz016UhmwxZxyTfwG8vhOZcDmlt47tm0+BIsa1Jvgn5n3606KjKZSC54hyNIbktuqYV2J79NGE/yaHPWSZPxYn0yEHHEBMsSuJ9PWZE0W2zDZzi10p1wYh+hyWYFpDgV9tkbMLfTN21vA+P6yvRt8+7ogsdeAAQxD+AFXvhGoHDEHr3H8UEp71SYMhI9x5gd6NFye5+N95sAAAAJ7rPnR+Xc72EVYW9YtWdOgRx5zO54cKYqaNg27yRAerTsPrO0V9nce3qO/xLuvijLxneP8lTh07AfI0G7tDqNtp6Ptr5/p2SgQmQBV/MxayA9lpLv64sMeIscfJ+bOm3f5ZWj6q71dc25IRwZ6NegtCcpx5FPOw7u6+ROp85NNppQE1VED3GXGhfkAAAAAi2hXgBHMGT9+YsUAX1gIAAAAAAAncFoAAAAAAAA=";

const sheetUrl = (id) => `https://docs.google.com/spreadsheets/d/${id}/edit`;
const fileUrl = (id) => `https://drive.google.com/file/d/${id}/view`;
const folderUrl = (id) => `https://drive.google.com/drive/folders/${id}`;

const DATA = [
  {
    no: "1",
    name: "Rencana Belajar",
    desc: "RPB bulanan — satu file per bulan, satu sheet per kelas",
    folderId: "1tstmlSl9OfCiyAJ5ekw9JM70mtdMIq4m",
    files: [
      { id: "1rfdzYgbgmK7tQuSTXBXTqM2PC0EY_pbY", name: "1. RPB Juli", type: "x" },
      { id: "19jw2Dk8bGBrzBLyrwKZvnJ7jdTRjuQqN", name: "2. RPB Agustus", type: "x" },
      { id: "1ThsWWAYvWgFAaTdCAwhrxj9oPC5lv2Of", name: "3. RPB September", type: "x" },
      { id: "1YhzzfZ-_lusgw6AHEFm3DcMAs-BVnf1Q", name: "4. RPB Oktober", type: "x" },
      { id: "1M2upQX7hfM6VmMoLOrDZxZ3BOVtrwKAl", name: "5. RPB November", type: "x" },
      { id: "1pVqSJgIieu3ThDqG_RVss1157TFR6o2l", name: "6. RPB Desember", type: "x" },
    ],
  },
  {
    no: "2",
    name: "Capaian Ilmu",
    desc: "Satu dokumen per kelas",
    folderId: "1jpMRD9VEdfXYHLJ4j1L7x2PICurNKTsd",
    groups: [
      {
        name: "Kuttab Awwal",
        folderId: "148KrzRk5Q4sUkWCWirZma9PjVxpdpnkG",
        files: [
          { id: "10NLBd_qUjG44UhhUg5vMNZFbCLWdXuXmGpnXxGhlBv0", name: "Kuttab Awwal 1", type: "g" },
          { id: "19wKQTp_vfBHbXMDgkkv47dQa-waHtuTOjNGHA3JJi4o", name: "Kuttab Awwal 2", type: "g" },
          { id: "1pmFMwloUNV4yULS-gk-rasvzKUXY_ua-u1jp63RhyPM", name: "Kuttab Awwal 3 Ikhwan", type: "g" },
          { id: "1ve99i_8UUeHdm1ejUYifQqnwIgaFZ8bZWMkWM3PAcKM", name: "Kuttab Awwal 3 Akhwat", type: "g" },
        ],
      },
      {
        name: "Qonuni",
        folderId: "1v4kAopz2VKJ6BM0pslrzzpP2OkgRWOx1",
        files: [
          { id: "17K_RJBuSr_Vnoio7DdnDo38Zzd70PSEfVg_lpkr_tik", name: "Qonuni 1 Ikhwan", type: "g" },
          { id: "1nM9GmLyHjLR0NzKIpnCDWbS2EzAA6h8liOEz8WT0GkU", name: "Qonuni 1 Akhwat", type: "g" },
          { id: "1VjYpSKAcJeyDRzoZm_TDsBM72uq1W2Jfz8zKY26wr3Q", name: "Qonuni 2 Ikhwan", type: "g" },
          { id: "1diktDxqFrkRl8CIs_-64co3wjqAzemM9NkXeIPLFdfA", name: "Qonuni 2 Akhwat", type: "g" },
          { id: "1JHPUj40g6TX4d9pT5ZgiULM_zZzgjD6ZHKBDMWiHj2w", name: "Qonuni 3 Ikhwan", type: "g" },
          { id: "1mP6SDhnjm1Z9xXmaSq3-QpxAJXcR2mroM3epTkjXZtA", name: "Qonuni 3 Akhwat", type: "g" },
          { id: "1lZPyKmAzApXL6CvmDe1httVUnGQXm210SCSWklS4j6s", name: "Qonuni 4 Ikhwan", type: "g" },
          { id: "1Zj2BB381u0leQNExQKWFxZAWrg_BfqT8RUGGNVpBmpU", name: "Qonuni 4 Akhwat", type: "g" },
        ],
      },
    ],
  },
  {
    no: "3",
    name: "Capaian Al-Qur'an",
    desc: "Capaian hafalan/bacaan — satu dokumen per kelas",
    folderId: "1iD-LlLuqotoL5JUnaBnvQ3OO_tEzgeig",
    groups: [
      {
        name: "Kuttab Awwal",
        folderId: "1A4RmqyIMoaPu0NNEce44dBFiOPRovlcC",
        files: [
          { id: "1-7dSky9nQJZOlaf2ffvosn7j4qaKemxhUYvaIBQ3SqQ", name: "Kuttab Awwal 1", type: "g" },
          { id: "1LuiI1Czpt3H6ZQMa8RQwDYz6pinKpyffxj0qkWZS6tc", name: "Kuttab Awwal 2", type: "g" },
          { id: "1mYqAeBNYLYFQg--OY8I7jRx2SCk_8ZTagE-DRSmgx70", name: "Kuttab Awwal 3 Ikhwan", type: "g" },
          { id: "1yIvXYqQv_SZpKdzcEpOJ9jj0RaEiBfGsfb7GDYDg7uw", name: "Kuttab Awwal 3 Akhwat", type: "g" },
        ],
      },
      {
        name: "Qonuni",
        folderId: "1FP0LW852lxu1_-u7RJRRe8nV6Hk7Fg1A",
        files: [
          { id: "1rZA37FA8h1OdcJ040y8EFF6hYAKIjnmFvVYRHa50qbk", name: "Qonuni 1 Ikhwan", type: "g" },
          { id: "1iI6BQ_BAdtx6uK-CThdN1ARfR0DDlYnltcL_OcgEybk", name: "Qonuni 1 Akhwat", type: "g" },
          { id: "1P1W29eZCrDRHt0Ko7U3sLcXdy0ASqmiUe43F4WUS1DA", name: "Qonuni 2 Ikhwan", type: "g" },
          { id: "15Aio-TmPQ00yuveGpaxLXXItYimHVuZpr0WagBrs50w", name: "Qonuni 2 Akhwat", type: "g" },
          { id: "1nwyO0ReKI0lS2qCKN6gMOcALCrVn5jD0vQydxzx9deM", name: "Qonuni 3 Ikhwan", type: "g" },
          { id: "1rDFMA861SfA7I1W7gYWRApKimPIUmlE4sTqzpcB6MlA", name: "Qonuni 3 Akhwat", type: "g" },
          { id: "1nRNc9EN3OlQytq2KX1ylTaU-63XbH4DCclLt_2szlb4", name: "Qonuni 4 Ikhwan", type: "g" },
          { id: "1ddeOUbrYYVSLxxjKKag7fApVz0-cOSlJ2zDkZe5MLXI", name: "Qonuni 4 Akhwat", type: "g" },
        ],
      },
    ],
  },
  {
    no: "4",
    name: "Refleksi Rencana Belajar",
    desc: "Refleksi guru terhadap RPB tiap bulan",
    folderId: "1ddBJljlHV1gL0c6v2OidEIDPtWn18qqI",
    files: [
      { id: "1rukZunfwdaCKXfXOSPaLRsqd06T7z1TP", name: "1. Juli", type: "x" },
      { id: "1i1TV5RmvuDdaMR73oexsR5TPlyilF0ah", name: "2. Agustus", type: "x" },
      { id: "1i29xY7IL4eW3KjaxPzp3m_Mii0-Bd4mm", name: "3. September", type: "x" },
      { id: "1yhaaYyn1y89ZlfPWxFa93jGOuF8Q7uYX", name: "4. Oktober", type: "x" },
      { id: "1C8Qo3aXf2EbwCsftdUaP3hf6NJ_WmaoL", name: "5. November", type: "x" },
      { id: "1xrtYH55ze3a4WTBfwqHhHbyB9jmoH18q", name: "6. Desember", type: "x" },
    ],
  },
];

const MAIN_FOLDER = "1avPwaPRmDYUbD_By1UYwMJGV7sowIEYD";
const SNAPSHOT_DATE = "18 Juli 2026";

// Pembatas emas ber-permata — motif dari logo
function GoldDivider() {
  return (
    <div className="flex items-center gap-2 my-1" aria-hidden="true">
      <span className="flex-1 h-px" style={{ background: C.gold, opacity: 0.55 }} />
      <svg width="10" height="10" viewBox="0 0 10 10">
        <rect x="2" y="2" width="6" height="6" transform="rotate(45 5 5)" fill={C.gold} />
      </svg>
      <span className="flex-1 h-px" style={{ background: C.gold, opacity: 0.55 }} />
    </div>
  );
}

function TypeBadge({ type }) {
  const isSheet = type === "g";
  return (
    <span
      className="text-[10px] px-1.5 py-0.5 rounded-full uppercase tracking-wide shrink-0"
      style={{
        background: isSheet ? C.leaf : C.goldSoft,
        color: isSheet ? C.green : "#8A6A20",
      }}
    >
      {isSheet ? "Sheet" : "Excel"}
    </span>
  );
}

function FileRow({ file }) {
  const url = file.type === "g" ? sheetUrl(file.id) : fileUrl(file.id);
  return (
    <div
      className="flex items-center justify-between gap-3 px-3.5 py-2.5 rounded-xl transition-shadow hover:shadow-sm"
      style={{ background: "#FFFFFF", border: `1px solid ${C.line}` }}
    >
      <div className="flex items-center gap-2.5 min-w-0">
        <svg width="14" height="14" viewBox="0 0 10 10" className="shrink-0">
          <rect x="2" y="2" width="6" height="6" transform="rotate(45 5 5)" fill="none" stroke={C.gold} strokeWidth="1.2" />
        </svg>
        <span className="truncate text-sm" style={{ color: C.ink }}>{file.name}</span>
        <TypeBadge type={file.type} />
      </div>
      <a
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        className="text-xs font-semibold px-3.5 py-1.5 rounded-full whitespace-nowrap transition-opacity hover:opacity-90"
        style={{ background: C.green, color: "#FFF" }}
      >
        Buka & isi
      </a>
    </div>
  );
}

function FileList({ files, filter }) {
  const shown = files.filter((f) => f.name.toLowerCase().includes(filter));
  if (!shown.length)
    return (
      <p className="text-sm px-1 py-2" style={{ color: C.muted }}>
        {filter ? "Tidak ada dokumen yang cocok dengan pencarian." : "Belum ada file — buka foldernya untuk menambahkan."}
      </p>
    );
  return <div className="space-y-2">{shown.map((f) => <FileRow key={f.id} file={f} />)}</div>;
}

function Section({ section, filter }) {
  const [open, setOpen] = useState(true);
  const count =
    (section.files?.length || 0) +
    (section.groups?.reduce((n, g) => n + g.files.length, 0) || 0);

  return (
    <section
      className="rounded-2xl overflow-hidden"
      style={{ background: "#FFFFFF", border: `1px solid ${C.line}`, boxShadow: "0 1px 2px rgba(28,74,51,0.05)" }}
    >
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between gap-3 px-4 sm:px-5 py-3.5 text-left"
        style={{ background: C.green }}
        aria-expanded={open}
      >
        <div className="flex items-center gap-3 min-w-0">
          <span
            className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shrink-0"
            style={{ background: "rgba(255,255,255,0.12)", color: C.gold, fontFamily: "Georgia, serif" }}
          >
            {section.no}
          </span>
          <div className="min-w-0">
            <div className="font-semibold truncate text-white">{section.name}</div>
            <div className="text-xs truncate" style={{ color: "rgba(255,255,255,0.72)" }}>{section.desc}</div>
          </div>
        </div>
        <div className="flex items-center gap-2.5 shrink-0">
          <span className="text-xs" style={{ color: C.gold }}>{count} file</span>
          <svg width="14" height="14" viewBox="0 0 24 24" style={{ transform: open ? "rotate(180deg)" : "none", transition: "transform .2s" }}>
            <path d="M6 9l6 6 6-6" fill="none" stroke="#FFF" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </div>
      </button>

      {open && (
        <div className="p-3.5 sm:p-4 space-y-4" style={{ background: C.mist }}>
          {section.files && <FileList files={section.files} filter={filter} />}
          {section.groups?.map((g) => (
            <div key={g.folderId}>
              <div className="flex items-center justify-between px-1 pb-2">
                <span className="text-xs font-bold uppercase tracking-[0.18em]" style={{ color: C.green }}>{g.name}</span>
                <a href={folderUrl(g.folderId)} target="_blank" rel="noopener noreferrer" className="text-xs underline" style={{ color: C.muted }}>
                  Buka folder
                </a>
              </div>
              <FileList files={g.files} filter={filter} />
            </div>
          ))}
          <a
            href={folderUrl(section.folderId)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block text-xs underline px-1"
            style={{ color: C.muted }}
          >
            Buka folder «{section.name}» di Drive →
          </a>
        </div>
      )}
    </section>
  );
}

export default function Portal() {
  const [query, setQuery] = useState("");
  const filter = query.trim().toLowerCase();

  const totalFiles = useMemo(
    () =>
      DATA.reduce(
        (n, s) => n + (s.files?.length || 0) + (s.groups?.reduce((m, g) => m + g.files.length, 0) || 0),
        0
      ),
    []
  );

  return (
    <div className="min-h-screen" style={{ background: C.mist, color: C.ink }}>
      {/* Pita hijau tipis di atas */}
      <div className="h-1.5" style={{ background: `linear-gradient(90deg, ${C.green}, ${C.gold}, ${C.green})` }} />

      <div className="max-w-3xl mx-auto px-4 py-7 sm:py-10">
        {/* Header berlogo */}
        <header className="text-center">
          <img
            src={LOGO}
            alt="Logo Kuttab Budi Ashari"
            className="mx-auto w-56 sm:w-64 h-auto"
            style={{ mixBlendMode: "multiply" }}
          />
          <div className="max-w-md mx-auto mt-4">
            <GoldDivider />
          </div>
          <h1
            className="text-xl sm:text-2xl font-semibold mt-3"
            style={{ color: C.green, fontFamily: "Georgia, 'Times New Roman', serif", letterSpacing: "0.02em" }}
          >
            Portal Evaluasi Kurikulum
          </h1>
          <p className="text-sm mt-2 max-w-md mx-auto" style={{ color: C.muted }}>
            Pilih dokumen kelas Anda, tekan <strong style={{ color: C.green }}>Buka & isi</strong>, lalu
            lengkapi evaluasinya langsung di Google Drive. {totalFiles} dokumen tersedia.
          </p>
        </header>

        {/* Pencarian */}
        <div className="mt-6">
          <div className="relative">
            <svg width="16" height="16" viewBox="0 0 24 24" className="absolute left-3.5 top-1/2 -translate-y-1/2">
              <circle cx="11" cy="11" r="7" fill="none" stroke={C.muted} strokeWidth="2" />
              <path d="M20 20l-3.5-3.5" stroke={C.muted} strokeWidth="2" strokeLinecap="round" />
            </svg>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Cari kelas atau dokumen… (mis. Qonuni 3)"
              className="w-full pl-10 pr-4 py-3 rounded-full text-sm outline-none focus:ring-2"
              style={{ background: "#FFF", border: `1px solid ${C.line}`, "--tw-ring-color": C.gold }}
              aria-label="Cari dokumen"
            />
          </div>
        </div>

        {/* Folder */}
        <main className="mt-6 space-y-4">
          {DATA.map((s) => (
            <Section key={s.no} section={s} filter={filter} />
          ))}
        </main>

        {/* Footer */}
        <footer className="mt-9 text-center text-xs space-y-2" style={{ color: C.muted }}>
          <div className="max-w-md mx-auto">
            <GoldDivider />
          </div>
          <p className="pt-1">
            Daftar file per {SNAPSHOT_DATE}. File baru di Drive?{" "}
            <a href={folderUrl(MAIN_FOLDER)} target="_blank" rel="noopener noreferrer" className="underline">
              Buka folder utama «7. Evaluasi Kurikulum»
            </a>
          </p>
          <p>Jika dokumen tidak bisa dibuka, minta akses ke koordinator kurikulum.</p>
          <p className="pt-1 font-semibold" style={{ color: C.green }}>Kuttab Budi Ashari</p>
        </footer>
      </div>
    </div>
  );
}
